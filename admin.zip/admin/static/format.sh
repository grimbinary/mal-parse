#!/bin/bash

# Create a temporary file
touch temp.json

# Variable to hold the sample name and signature
sample_info=""

# Write the opening bracket of the array to the temporary file
echo "[" >> temp.json

# Read the report.json file line by line
while IFS= read -r line
do
  # Check if the line contains "Sample:"
  if [[ $line == *"Sample:"* ]]; then
    # Extract the sample name and signature part
    sample_name=$(echo $line | cut -d':' -f2 | xargs)
    signature=$(echo $line | cut -d':' -f3 | xargs)
    # Store the sample name and signature in the sample_info variable
    sample_info="\"sample_name\": \"$sample_name\","
  elif [[ $line == *"\"data\": {"* ]]; then
    # If the line contains "\"data\": {", insert the sample_info inside the "data" object
    echo "${line::-1}{ $sample_info" >> temp.json
    # Reset the sample_info variable
    sample_info=""
  else
    # If the line does not contain "Sample:" or "\"data\": {", write it to the temporary file as is
    echo $line >> temp.json
  fi
done < new_threats.json

# Write the closing brace and the closing bracket of the array to the temporary file
echo "}" >> temp.json
echo "]" >> temp.json

# Replace the original file with the temporary file
mv temp.json threats.json

# Replace "}\n\n{" with "}\n},\n{" in the threats.json file
sed -i ':a;N;$!ba;s/}\n\n{/}\n},\n{/g' threats.json

# Remove occurrences of "\"data\": {}" from the threats.json file
sed -i '/"data": {}/d' threats.json
