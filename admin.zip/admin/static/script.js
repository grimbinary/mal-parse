let points = [];
let tickSpeed = 10;
let base = 180;
let numPoints = 10;
let maxTicks = 3000;
let ticks = 0;

function Point(x = random(width), y = random(height), a = random(PI)){
  this.x = x;
  this.y = y;
  this.a = a;
  this.dx = cos(a);
  this.dy = sin(a);
  this.hue = (random(100) + base)%360;
  this.color = color(this.hue, 100, 100, .01);
}

Point.prototype.update = function(){
  this.x += this.dx;
  this.y += this.dy;
  if (this.x < 0 || this.x >= width) this.dx *= -1;
  if (this.y < 0 || this.y >= height) this.dy *= -1;
  stroke(this.color);
  line(this.x, this.y, this.neighbor.x, this.neighbor.y);
}

function setup(){
  createCanvas();
  colorMode(HSB);
  windowResized();
  blendMode(ADD);
  strokeWeight(1.5);
}

function init(){
  points = [];
  base = random(360);
  ticks = 0;
  
  for (var i = 0; i < numPoints; i++) points.push(new Point());
  
  for (var i = 0; i < points.length; i++){
    let j = i;
    while(j == i) j = floor(random(points.length));
    points[i].neighbor = points[j];
  }
}

function draw(){
  if (ticks > maxTicks) return;
  for (var n = 0; n < tickSpeed; n++){
    for (var i = 0; i < points.length; i++){
      points[i].update();
    }
    ticks++;
  }
}

function mouseClicked(){
  windowResized();
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  pixelDensity(1);
  clear();
  background(0);
  init();
}


// declare and initialize darkmodeEnabled
let darkmodeEnabled = false;

function toggleDarkMode () {
    // add fomantic's inverted class to all ui elements
    $('body').find('.ui').addClass('inverted');
    // add custom inverted class to body
    $('body').addClass('inverted');

    // simple toggle icon change
    $("#darkmode > i").removeClass('moon');
    $("#darkmode > i").addClass('sun');

    // update darkmodeEnabled
    darkmodeEnabled = true;

    return;
}

function toggleLightMode() {
    // remove fomantic's inverted from all ui elements
    $('body').find('.ui').removeClass('inverted');
    // remove custom inverted class to body
    $('body').removeClass('inverted');

    // change button icon
    $("#darkmode > i").removeClass('sun')
    $("#darkmode > i").addClass('moon');

    // update darkmodeEnabled
    darkmodeEnabled = false;

    return;
}

$('#darkmode').click(function () {
    if (darkmodeEnabled) {
        toggleLightMode();
    } else {
        toggleDarkMode();
    }
});


var scrollToTopButton = document.getElementById('scrollToTopButton');

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        scrollToTopButton.style.display = "block";
    } else {
        scrollToTopButton.style.display = "none";
    }
};

// When the user clicks on the button, scroll to the top of the document
scrollToTopButton.onclick = function() {
    document.body.scrollTop = 0;  // For Safari
    document.documentElement.scrollTop = 0;  // For Chrome, Firefox, IE and Opera
}


// Get the legend and the button
var legend = document.getElementById('legend');
var button = document.getElementById('toggleLegend');

// Initially hide the legend and change the button icon to a map icon
legend.style.display = 'none';
button.innerHTML = '<i class="fas fa-map"></i>';

// Add a click event listener to the button
button.addEventListener('click', function() {
    // If the legend is currently displayed, hide it
    if (legend.style.display !== 'none') {
        legend.style.display = 'none';
        // Change the button icon to a map icon
        button.innerHTML = '<i class="fas fa-map"></i>';
    }
    // If the legend is currently hidden, display it
    else {
        legend.style.display = 'block';
        // Change the button icon to a key icon
        button.innerHTML = '<i class="fas fa-key"></i>';
    }
});


//URI to fetch data from
var DATA_URL = "/formatted_report.json";

function generateColor(i, total) {
    var hue = i / total;
    return `hsla(${hue * 360}, 75%, 50%, 0.3)`;
}

/////////////////////////////////////////////////////////////////////////////////////
//Charts - pt 1

//bar
fetch(DATA_URL)
.then(response => response.json())
.then(data => {
        var counts = {};
        data.forEach(d => {
            // If origin_country is null, replace it with 'Unknown'
            var origin_country = d.origin_country || 'Unknown';
            if (!counts[origin_country]) {
                counts[origin_country] = {};
            }            var signature = d.signature || 'Unknown';
            if (counts[origin_country][signature]) {
                counts[origin_country][signature]++;
            } else {
                counts[origin_country][signature] = 1;
            }
        });
        
        var labels = Object.keys(counts);
        var datasets = [];
        var signatureIndexMap = {}; 
        Object.values(counts).forEach((signatureCounts, index) => {
            var signatures = Object.keys(signatureCounts);
            var signatureCountsArray = Object.values(signatureCounts);
            signatures.forEach((signature, i) => {
                if (!signatureIndexMap[signature]) {
                    datasets.push({
                        label: signature,
                        data: [],
                        backgroundColor: `rgba(${Math.random() * 255}, ${Math.random() * 255}, ${Math.random() * 255}, 0.2)`,
                        borderColor: `rgba(${Math.random() * 255}, ${Math.random() * 255}, ${Math.random() * 255}, 1)`,
                        borderWidth: 1
                    });
                    signatureIndexMap[signature] = datasets.length - 1;
                }
                datasets[signatureIndexMap[signature]].data[index] = signatureCountsArray[i];
            });
        });
        var ctx = document.getElementById('myChart01a');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: datasets
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    })
    .catch(error => console.error('Error:', error));
    
    //line
    fetch(DATA_URL)
        .then(response => response.json())
        .then(data => {
            var counts = {};
            data.forEach(d => {
                d.origin_country = d.origin_country || 'Unknown';
                d.signature = d.signature || 'Unknown';
    
                if (!counts[d.origin_country]) {
                    counts[d.origin_country] = {};
                }
                if (counts[d.origin_country][d.signature]) {
                    counts[d.origin_country][d.signature]++;
                } else {
                    counts[d.origin_country][d.signature] = 1;
                }
            });
            var uniqueSignatures = [...new Set(data.map(d => d.signature))];
            var datasets = uniqueSignatures.map(signature => {
                var backgroundColor = `rgba(${Math.random() * 255}, ${Math.random() * 255}, ${Math.random() * 255}, 0.5)`;
                var borderColor = `rgba(${Math.random() * 255}, ${Math.random() * 255}, ${Math.random() * 255}, 1)`;
                return {
                    label: signature,
                    data: Object.values(counts).map(country => country[signature] || 0),
                    fill: false,
                    backgroundColor: backgroundColor,
                    borderColor: borderColor,
                    borderWidth: 1
                };
            });
    
            var ctx = document.getElementById('myChart01b');
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: Object.keys(counts),
                    datasets: datasets
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        })
        .catch(error => console.error('Error:', error));
    
    //pie
    fetch(DATA_URL)
    .then(response => response.json())
    .then(data => {
        var counts = {};
        data.forEach(d => {
            if (!counts[d.origin_country]) {
                counts[d.origin_country] = {};
            }
            if (counts[d.origin_country][d.signature]) {
                counts[d.origin_country][d.signature]++;
            } else {
                counts[d.origin_country][d.signature] = 1;
            }
        });

        var labels = Object.keys(counts);
        var datasets = [];
        Object.values(counts).forEach((signatureCounts, index) => {
            var signatures = Object.keys(signatureCounts);
            var signatureCountsArray = Object.values(signatureCounts);
            var colors = signatures.map((_, i) => generateColor(i, signatures.length));
            var dataset = {
                label: 'Signatures',
                data: signatureCountsArray,
                backgroundColor: colors,
                borderColor: colors,
                borderWidth: 1
            };
            datasets.push(dataset);
        });

        var ctx = document.getElementById('myChart01c');
        new Chart(ctx, {
            type: 'pie',
            data: {
                labels: labels,
                datasets: datasets
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    })
    .catch(error => console.error('Error:', error));

    //polar

    fetch(DATA_URL)
    .then(response => response.json())
    .then(data => {
        var counts = {};
        data.forEach(d => {
            if (!counts[d.origin_country]) {
                counts[d.origin_country] = {};
            }
            if (counts[d.origin_country][d.signature]) {
                counts[d.origin_country][d.signature]++;
            } else {
                counts[d.origin_country][d.signature] = 1;
            }
        });

        var labels = Object.keys(counts);
        var datasets = [];
        Object.values(counts).forEach((signatureCounts, index) => {
            var signatures = Object.keys(signatureCounts);
            var signatureCountsArray = Object.values(signatureCounts);
            var colors = signatures.map((_, i) => generateColor(i, signatures.length));
            var dataset = {
                label: 'Signatures',
                data: signatureCountsArray,
                backgroundColor: colors,
                borderColor: colors,
                borderWidth: 1
            };
            datasets.push(dataset);
        });

        var ctx = document.getElementById('myChart01d');
        new Chart(ctx, {
            type: 'polarArea',
            data: {
                labels: labels,
                datasets: datasets
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    })
    .catch(error => console.error('Error:', error));


    /////////////////////////////////////////////////////////////////////////////////
    // Charts - pt 2

    //bar
    fetch(DATA_URL)
    .then(response => response.json())
    .then(data => {
            var counts = {};
            data.forEach(d => {
     
                var delivery_method = d.delivery_method || 'Unknown';
                if (!counts[delivery_method]) {
                    counts[delivery_method] = {};
                }
                var signature = d.signature || 'Unknown';
                if (counts[delivery_method][signature]) {
                    counts[delivery_method][signature]++;
                } else {
                    counts[delivery_method][signature] = 1;
                }
            });
            
            var labels = Object.keys(counts);
            var datasets = [];
            var signatureIndexMap = {}; 
            Object.values(counts).forEach((signatureCounts, index) => {
                var signatures = Object.keys(signatureCounts);
                var signatureCountsArray = Object.values(signatureCounts);
                signatures.forEach((signature, i) => {
                    if (!signatureIndexMap[signature]) {
                        datasets.push({
                            label: signature,
                            data: [],
                            backgroundColor: `rgba(${Math.random() * 255}, ${Math.random() * 255}, ${Math.random() * 255}, 0.2)`,
                            borderColor: `rgba(${Math.random() * 255}, ${Math.random() * 255}, ${Math.random() * 255}, 1)`,
                            borderWidth: 1
                        });
                        signatureIndexMap[signature] = datasets.length - 1;
                    }
                    datasets[signatureIndexMap[signature]].data[index] = signatureCountsArray[i];
                });
            });
            var ctx = document.getElementById('myChart02a');
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: datasets
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        })
        .catch(error => console.error('Error:', error));

//line

fetch(DATA_URL)
.then(response => response.json())
.then(data => {
        var counts = {};
        data.forEach(d => {
 
            var delivery_method = d.delivery_method || 'Unknown';
            if (!counts[delivery_method]) {
                counts[delivery_method] = {};
            }
            var signature = d.signature || 'Unknown';
            if (counts[delivery_method][signature]) {
                counts[delivery_method][signature]++;
            } else {
                counts[delivery_method][signature] = 1;
            }
        });
        
        var labels = Object.keys(counts);
        var datasets = [];
        var signatureIndexMap = {}; 
        Object.values(counts).forEach((signatureCounts, index) => {
            var signatures = Object.keys(signatureCounts);
            var signatureCountsArray = Object.values(signatureCounts);
            signatures.forEach((signature, i) => {
                if (!signatureIndexMap[signature]) {
                    datasets.push({
                        label: signature,
                        data: [],
                        backgroundColor: `rgba(${Math.random() * 255}, ${Math.random() * 255}, ${Math.random() * 255}, 0.2)`,
                        borderColor: `rgba(${Math.random() * 255}, ${Math.random() * 255}, ${Math.random() * 255}, 1)`,
                        borderWidth: 1
                    });
                    signatureIndexMap[signature] = datasets.length - 1;
                }
                datasets[signatureIndexMap[signature]].data[index] = signatureCountsArray[i];
            });
        });
        var ctx = document.getElementById('myChart02b');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: datasets
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    })
    .catch(error => console.error('Error:', error));

//Radar
fetch(DATA_URL)
.then(response => response.json())
.then(data => {
    var counts = {};
    var allSignatures = new Set();
    data.forEach(d => {
        var delivery_method = d.delivery_method || 'Unknown';
        if (!counts[delivery_method]) {
            counts[delivery_method] = {};
        }
        var signature = d.signature || 'Unknown';
        allSignatures.add(signature);
        if (counts[delivery_method][signature]) {
            counts[delivery_method][signature]++;
        } else {
            counts[delivery_method][signature] = 1;
        }
    });

    var labels = Object.keys(counts);
    var datasets = [];
    allSignatures = Array.from(allSignatures);

    allSignatures.forEach((signature, i) => {
        var data = labels.map(label => counts[label][signature] || 0);
        var color = generateColor(i, allSignatures.length);
        var dataset = {
            label: signature,
            data: data,
            backgroundColor: color,
            borderColor: color,
            borderWidth: 1
        };
        datasets.push(dataset);
    });

    var ctx = document.getElementById('myChart02c');
    new Chart(ctx, {
        type: 'radar',
        data: {
            labels: labels,
            datasets: datasets
        },
        options: {
            scales: {
                r: {
                    beginAtZero: true
                }
            }
        }
    });
})
.catch(error => console.error('Error:', error));



//polar
fetch(DATA_URL)
.then(response => response.json())
.then(data => {
        var counts = {};
        data.forEach(d => {
 
            var delivery_method = d.delivery_method || 'Unknown';
            if (!counts[delivery_method]) {
                counts[delivery_method] = {};
            }
            var signature = d.signature || 'Unknown';
            if (counts[delivery_method][signature]) {
                counts[delivery_method][signature]++;
            } else {
                counts[delivery_method][signature] = 1;
            }
        });

        var labels = Object.keys(counts);
        var datasets = [];
        Object.values(counts).forEach((signatureCounts, index) => {
            var signatures = Object.keys(signatureCounts);
            var signatureCountsArray = Object.values(signatureCounts);
            var colors = signatures.map((_, i) => generateColor(i, signatures.length));
            var dataset = {
                label: 'Signatures',
                data: signatureCountsArray,
                backgroundColor: colors,
                borderColor: colors,
                borderWidth: 1
            };
            datasets.push(dataset);
        });

        var ctx = document.getElementById('myChart02d');
        new Chart(ctx, {
            type: 'polarArea',
            data: {
                labels: labels,
                datasets: datasets
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    })
    .catch(error => console.error('Error:', error));

    /////////////////////////////////////////////////////////////////////////////////
    //Charts pt 3
    //bar
    fetch(DATA_URL)
    .then(response => response.json())
    .then(data => {
        var counts = {};
        data.forEach(d => {
            // Use reporter in place of delivery_method
            var reporter = d.reporter || 'Unknown';
            if (!counts[reporter]) {
                counts[reporter] = 1;
            } else {
                counts[reporter]++;
            }
        });
    
        var labels = Object.keys(counts);
        var data = Object.values(counts);
        var datasets = [{
            label: 'Reports',
            data: data,
            backgroundColor: `rgba(${Math.random() * 255}, ${Math.random() * 255}, ${Math.random() * 255}, 0.2)`,
            borderColor: `rgba(${Math.random() * 255}, ${Math.random() * 255}, ${Math.random() * 255}, 1)`,
            borderWidth: 1,
            fill: false // Set fill to false for line graph
        }];
    
        var ctx = document.getElementById('myChart03a');
        new Chart(ctx, {
            type: 'bar', // Change type to 'line'
            data: {
                labels: labels,
                datasets: datasets
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    })
    .catch(error => console.error('Error:', error));

    
//////////////////////////////////////////////////////////////////////////////////
//Threat Anaylsis - pt 1 

fetch('/daily_threats.json')
    .then(response => response.json())
    .then(data => {
        data.forEach(entry => {
            if (Array.isArray(entry.signature_desc)) {
                entry.signature_desc = entry.signature_desc.join(', ');
            }
        });

        let summary = {
            'Malware Types': {},
            'Vendor Hits': {},
            'Tactics': {},
            'Techniques': {},
            'Signature Descriptions': {}
        };

        data.forEach(entry => {
            summary['Malware Types'][entry.sample_name] = (summary['Malware Types'][entry.sample_name] || 0) + 1;
            summary['Vendor Hits'][entry.vendor] = (summary['Vendor Hits'][entry.vendor] || 0) + 1;
            summary['Tactics'][entry.tactic_id + " : " + entry.tactic_name] = (summary['Tactics'][entry.tactic_id + " : " + entry.tactic_name] || 0) + 1;
            summary['Techniques'][entry.technique_id + " : " + entry.technique_name] = (summary['Techniques'][entry.technique_id + " : " + entry.technique_name] || 0) + 1;
            summary['Signature Descriptions'][entry.signature_desc] = (summary['Signature Descriptions'][entry.signature_desc] || 0) + 1;
        });


let summaryDiv = document.getElementById('threat-summary');

//summary - pt2 
for (let category in summary) {
    let h3 = document.createElement('h3');
    h3.textContent = category + ':';
    h3.className = 'summary-header';
    summaryDiv.appendChild(h3);
    
    
    let itemsArray = Object.keys(summary[category]).map(item => [item, summary[category][item]]);
    itemsArray.sort((a, b) => b[1] - a[1]);
    
    
    for (let i = 0; i < itemsArray.length; i++) {
        let p = document.createElement('p');
        p.textContent = '  ' + itemsArray[i][0] + ': ' + itemsArray[i][1];
        summaryDiv.appendChild(p);
    }
}
      
var table = new Tabulator("#threats", {
    data: data, 
    layout: "fitColumns", 
    columns: [
        {title: "Sample Name", field: "sample_name", width: 150},
        {title: "Vendor", field: "vendor", width: 150},
        {title: "Tactic ID", field: "tactic_id", width: 150},
        {title: "Tactic Name", field: "tactic_name", width: 200},
        {title: "Technique ID", field: "technique_id", width: 200},
        {title: "Technique Name", field: "technique_name", width: 350},
        {title: "Signature Description", field: "signature_desc", width: 150000},
        ],
    });
})
.catch(error => console.error('Error:', error));

//////////////////////////////////////////////////////////////////////////////////
//Visual tab - Pt 2


// Define the margins, width and height for the SVG
var margin = {top: 20, right: 20, bottom: 30, left: 40},
    width = 960 - margin.left - margin.right,
    height = 500 - margin.top - margin.bottom;

// Set up the x scale
var x = d3.scaleBand()
          .rangeRound([0, width])
          .padding(0.1);

// Set up the y scale
var y = d3.scaleLinear()
          .rangeRound([height, 0]);

// Create the SVG element
var svg1 = d3.select("#threat-visual").append("svg")
    .attr("viewBox", `0 0 ${width + margin.left + margin.right} ${height + margin.top + margin.bottom}`)
    .append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

//Get data
fetch('/daily_threats.json')
    .then(response => response.json())
    .then(data => {
        // Convert the malware types to an array
        var malwareTypes = data.map(function(d) { return d.sample_name; });
        
        // Count the occurrences of each malware type
        var counts = {};
        malwareTypes.forEach(function(i) { counts[i] = (counts[i] || 0) + 1; });
        
        // Convert the counts object to an array of objects
        var countArray = Object.keys(counts).map(function(key) {
            return {
                type: key,
                count: counts[key]
            };
        });

// Set up the domains for the scales
var color = d3.scaleOrdinal(d3.schemeCategory10);
    
x.domain(countArray.map(function(d) { return d.type; }));
y.domain([0, d3.max(countArray, function(d) { return d.count; })]);

// Add the text labels
    svg1.selectAll(".text")
    .data(countArray)
    .enter()
    .append("text")
    .text(function(d) { return d.count; })
    .attr("x", function(d) { return x(d.type) + x.bandwidth() / 2; })
    .attr("y", function(d) { return y(d.count) - 11; }) // Shift the text up by 5 units
    .attr("text-anchor", "middle")
    .attr("font-size", "12px")
    .attr("fill", function(d) { return darkmodeEnabled ? "var(--bar-color)" : color(d.type); })

// Add a title
svg1.append("text")
    .attr("x", 470)             
    .attr("y", 1)
    .attr("text-anchor", "middle")  
    .style("font-size", "16px") 
    .style("text-decoration", "underline")  
    .text("TTP Hits")
    .style("fill", "var(--text-color)")

    svg1.selectAll(".bar")
    .data(countArray)
    .enter().append("rect")
    .attr("class", "bar")
    .attr("x", function(d) { return x(d.type); })
    .attr("y", function(d) { return y(d.count); })
    .attr("width", x.bandwidth())
    .attr("height", function(d) { return height - y(d.count); })
    .attr("fill", function(d) { return color(d.type); })
    .attr("fill", function(d) { return darkmodeEnabled ? "var(--bar-color)" : color(d.type); })

    svg1.selectAll(".label")
    .data(countArray)
    .enter().append("text")
    .attr("class", "label")
    .attr("x", function(d) { return x(d.type) + (x.bandwidth() / 2); }) // center the label
    .attr("y", function(d) { return y(d.count) - 2; }) // position it slightly above the bar
    .text(function(d) { return d.type; }) // the text to display
    .attr("text-anchor", "middle") // center the text
    .attr("font-size", "10px") // adjust as needed
    .attr("fill", function(d) { return darkmodeEnabled ? "var(--bar-color)" : color(d.type); })
    })
    .catch(error => console.error('Error:', error));

/////////////////////////////////////////////////////////////////////////////////////
// Matrix - pt 1

// Define the tactics for each cell - updated 2023 - simply close this
        var tactics = [
            {
                "name": "Reconnaissance",
                "techniques": [
                    {
                        "name": "Active Scanning",
                        "subtechniques": [
                            "Scanning IP Blocks",
                            "Vulnerability Scanning",
                            "Wordlist Scanning"
                        ]
                    },
                    {
                        "name": "Gather Victim Host Information",
                        "subtechniques": [
                            "Hardware",
                            "Software",
                            "Firmware",
                            "Client Configurations"
                        ]
                    },
                    {
                        "name": "Gather Victim Identity Information",
                        "subtechniques": [
                            "Credentials",
                            "Email Addresses",
                            "Employee Names"
                        ]
                    },
                    {
                        "name": "Gather Victim Network Information",
                        "subtechniques": [
                            "Domain Properties",
                            "DNS",
                            "Network Trust Dependencies",
                            "Network Topology",
                            "IP Addresses",
                            "Network Security Appliances"
                        ]
                    },
                    {
                        "name": "Gather Victim Org Information",
                        "subtechniques": [
                            "Determine Physical Locations",
                            "Business Relationships",
                            "Identify Business Tempo",
                            "Identify Roles"
                        ]
                    },
                    {
                        "name": "Phishing for Information",
                        "subtechniques": [
                            "Spearphishing Service",
                            "Spearphishing Attachment",
                            "Spearphishing Link"
                        ]
                    },
                    {
                        "name": "Search Closed Sources",
                        "subtechniques": [
                            "Threat Intel Vendors",
                            "Purchase Technical Data"
                        ]
                    },
                    {
                        "name": "Search Open Technical Databases",
                        "subtechniques": [
                            "DNS/Passive DNS",
                            "WHOIS",
                            "Digital Certificates",
                            "CDNs",
                            "Scan Databases"
                        ]
                    },
                    {
                        "name": "Search Open Websites/Domains",
                        "subtechniques": [
                            "Social Media",
                            "Search Engines",
                            "Code Repositories"
                        ]
                    },
                    {
                        "name": "Search Victim-Owned Websites",
                        "subtechniques": [
                            "None"
                        ]
                    }
                ]
            },
            {
                "name": "Resource Development",
                "techniques": [
                    {
                        "name": "Acquire Access",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Acquire Infrastructure",
                        "subtechniques": [
                            "Domains",
                            "DNS Server",
                            "Virtual Private Server",
                            "Server",
                            "Botnet",
                            "Web Services",
                            "Serverless",
                            "Malvertising"
                        ]
                    },
                    {
                        "name": "Compromise Accounts",
                        "subtechniques": [
                            "Social Media Accounts",
                            "Email Accounts",
                            "Cloud Accounts"
                        ]
                    },
                    {
                        "name": "Compromise Infrastructure",
                        "subtechniques": [
                            "Domains",
                            "DNS Server",
                            "Virtual Private Server",
                            "Server",
                            "Botnet",
                            "Web Services",
                            "Serverless"
                        ]
                    },
                    {
                        "name": "Develop Capabilities",
                        "subtechniques": [
                            "Malware",
                            "Code Signing Certificates",
                            "Digital Certificates",
                            "Exploits"
                        ]
                    },
                    {
                        "name": "Establish Accounts",
                        "subtechniques": [
                            "Social Media Accounts",
                            "Email Accounts",
                            "Cloud Accounts"
                        ]
                    },
                    {
                        "name": "Obtain Capabilities",
                        "subtechniques": [
                            "Malware",
                            "Tool",
                            "Code Signing Certificates",
                            "Digital Certificates",
                            "Exploits",
                            "Vulnerabilities"
                        ]
                    },
                    {
                        "name": "Stage Capabilities",
                        "subtechniques": [
                            "Upload Malware",
                            "Upload Tool",
                            "Install Digital Certificate",
                            "Drive-by Target",
                            "Link Target",
                            "SEO Poisoning"
                        ]
                    }
                ]
            },
            {
                "name": "Initial Access",
                "techniques": [
                    {
                        "name": "Drive-by Compromise",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Exploit Public-Facing Application",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "External Remote Services",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Hardware Additions",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Phishing",
                        "subtechniques": [
                            "Spearphishing Attachment",
                            "Spearphishing Link",
                            "Spearphishing via Service"
                        ]
                    },
                    {
                        "name": "Replication Through Removable Media",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Supply Chain Compromise",
                        "subtechniques": [
                            "Compromise Software Dependencies and Development Tools",
                            "Compromise Software Supply Chain",
                            "Compromise Hardware Supply Chain"
                        ]
                    },
                    {
                        "name": "Trusted Relationship",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Valid Accounts",
                        "subtechniques": [
                            "Default Accounts",
                            "Domain Accounts",
                            "Local Accounts",
                            "Cloud Accounts"
                        ]
                    }
                ]
            },
            {
                "name": "Execution",
                "techniques": [
                    {
                        "name": "Cloud Administration Command",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Command and Scripting Interpreter",
                        "subtechniques": [
                            "PowerShell",
                            "AppleScript",
                            "Windows Command Shell",
                            "Unix Shell",
                            "Visual Basic",
                            "Python",
                            "JavaScript",
                            "Network Device CLI",
                            "Cloud API"
                        ]
                    },
                    {
                        "name": "Container Administrator Command",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Deploy Container",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Exploitation for Client Execution",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Inter-Process Communication",
                        "subtechniques": [
                            "Component Object Model",
                            "Dynamic Data Exchange",
                            "XPC Services"
                        ]
                    },
                    {
                        "name": "Scheduled Task/Job",
                        "subtechniques": [
                            "At",
                            "Cron",
                            "Scheduled Task",
                            "Systemd Timers",
                            "Container Orchestration Job"
                        ]
                    },
                    {
                        "name": "Severless Execution",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Shared Modules",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Software Deployment Tools",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "System Services",
                        "subtechniques": [
                            "Launchctl",
                            "Service Execution"
                        ]
                    },
                    {
                        "name": "User Execution",
                        "subtechniques": [
                            "Malicious Link",
                            "Malicious File",
                            "Malicious Image"
                        ]
                    },
                    {
                        "name": "Windows Management Instrumentation",
                        "subtechniques": [
                            "None"
                        ]
                    }
                ]
            },
            {
                "name": "Persistence",
                "techniques": [
                    {
                        "name": "Account Manipulation",
                        "subtechniques": [
                            "Additional Cloud Credentials",
                            "Additional Email Delegate Permissions",
                            "Additional Cloud Roles",
                            "SSH Authorized Keys",
                            "Device Registration"
                        ]
                    },
                    {
                        "name": "BITS Jobs",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Boot or Logon Autostart Execution",
                        "subtechniques": [
                            "Registry Run Keys / Startup Folder",
                            "Authentication Package",
                            "Time Providers",
                            "Winlogon Helper DLL",
                            "Security Support Provider",
                            "Kernel Modules and Extensions",
                            "Re-opened Applications",
                            "LSASS Driver",
                            "Shortcut Modification",
                            "Port Monitors",
                            "Print Processors",
                            "XDG Autostart Entries",
                            "Active Setup",
                            "Login Items"
                        ]
                    },
                    {
                        "name": "Boot or Logon Initialization Scripts",
                        "subtechniques": [
                            "Logon Script (Windows)",
                            "Login Hook",
                            "Network Logon Script",
                            "RC Scripts",
                            "Startup Items"
                        ]
                    },
                    {
                        "name": "Browser Extensions",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Compromise Client Software Binary",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Create Account",
                        "subtechniques": [
                            "Local Account",
                            "Domain Account",
                            "Cloud Account"
                        ]
                    },
                    {
                        "name": "Create or Modify System Process",
                        "subtechniques": [
                            "Launch Agent",
                            "Systemd Service",
                            "Windows Service",
                            "Launch Daemon"
                        ]
                    },
                    {
                        "name": "Event Triggered Execution",
                        "subtechniques": [
                            "Change Default File Association",
                            "Screensaver",
                            "Windows Management Instrumentation Event Subscription",
                            "Unix Shell Configuration Modification",
                            "Trap",
                            "LC_LOAD_DYLIB Addition",
                            "Netsh Helper DLL",
                            "Accessibility Features",
                            "AppCert DLLs",
                            "AppInit DLLs",
                            "Application Shimming",
                            "Image File Execution Options Injection",
                            "PowerShell Profile",
                            "Emond",
                            "Component Object Model Hijacking",
                            "Installer Packages"
                        ]
                    },
                    {
                        "name": "External Remote Services",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Hijack Execution Flow",
                        "subtechniques": [
                            "DLL Search Order Hijacking",
                            "DLL Side-Loading",
                            "Dylib Hijacking",
                            "Executable Installer File Permissions Weakness",
                            "Dynamic Linker Hijacking",
                            "Path Interception by PATH Environment Variable",
                            "Path Interception by Search Order Hijacking",
                            "Path Interception by Unquoted Path",
                            "Services File Permissions Weakness",
                            "Services Registry Permissions Weakness",
                            "COR_PROFILER",
                            "KernelCallbackTable"
                        ]
                    },
                    {
                        "name": "Implant Internal Image",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Modify Authentication Process",
                        "subtechniques": [
                            "Domain Controller Authentication",
                            "Password Filter DLL",
                            "Pluggable Authentication Modules",
                            "Network Device Authentication",
                            "Reversible Encryption",
                            "Multi-Factor Authentication",
                            "Hybrid Identity",
                            "Network Provider DLL"
                        ]
                    },
                    {
                        "name": "Office Application Startup",
                        "subtechniques": [
                            "Office Template Macros",
                            "Office Test",
                            "Outlook Forms",
                            "Outlook Home Page",
                            "Outlook Rules",
                            "Add-ins"
                        ]
                    },
                    {
                        "name": "Pre-OS Boot",
                        "subtechniques": [
                            "System Firmware",
                            "Component Firmware",
                            "Bootkit",
                            "ROMMONkit",
                            "TFTP Boot"
                        ]
                    },
                    {
                        "name": "Scheduled Task/Job",
                        "subtechniques": [
                            "At",
                            "Cron",
                            "Scheduled Task",
                            "Systemd Timers",
                            "Container Orchestration Job"
                        ]
                    },
                    {
                        "name": "Server Software Component",
                        "subtechniques": [
                            "SQL Stored Procedures",
                            "Transport Agent",
                            "Web Shell",
                            "IIS Components",
                            "Terminal Services DLL"
                        ]
                    },
                    {
                        "name": "Traffic Signaling",
                        "subtechniques": [
                            "Port Knocking",
                            "Socket Filters"
                        ]
                    },
                    {
                        "name": "Valid Accounts",
                        "subtechniques": [
                            "Default Accounts",
                            "Domain Accounts",
                            "Local Accounts",
                            "Cloud Accounts"
                        ]
                    }
                ]
            },
            {
                "name": "Privilege Escalation",
                "techniques": [
                    {
                        "name": "Abuse Elevation Control Mechanism",
                        "subtechniques": [
                            "Setuid and Setgid",
                            "Bypass User Account Control",
                            "Sudo and Sudo Caching",
                            "Elevated Execution with Prompt"
                        ]
                    },
                    {
                        "name": "Access Token Manipulation",
                        "subtechniques": [
                            "Token Impersonation/Theft",
                            "Create Process with Token",
                            "Make and Impersonate Token",
                            "Parent PID Spoofing",
                            "SID-History Injection",
                            "BITS Jobs",
                            "Build Image on Host",
                            "Debugger Evasion",
                            "Deobfuscate/Decode Files or Information",
                            "Deploy Container",
                            "Direct Volume Access"
                        ]
                    },
                    {
                        "name": "Boot or Logon Autostart Execution",
                        "subtechniques": [
                            "Registry Run Keys / Startup Folder",
                            "Authentication Package",
                            "Time Providers",
                            "Winlogon Helper DLL",
                            "Security Support Provider",
                            "Kernel Modules and Extensions",
                            "Re-opened Applications",
                            "LSASS Driver",
                            "Shortcut Modification",
                            "Port Monitors",
                            "Print Processors",
                            "XDG Autostart Entries",
                            "Active Setup",
                            "Login Items"
                        ]
                    },
                    {
                        "name": "Boot or Logon Initialization Scripts",
                        "subtechniques": [
                            "Logon Script (Windows)",
                            "Login Hook",
                            "Network Logon Script",
                            "RC Scripts",
                            "Startup Items"
                        ]
                    },
                    {
                        "name": "Create or Modify System Process",
                        "subtechniques": [
                            "Launch Agent",
                            "Systemd Service",
                            "Windows Service",
                            "Launch Daemon"
                        ]
                    },
                    {
                        "name": "Domain Policy Modification",
                        "subtechniques": [
                            "Group Policy Modification",
                            "Domain Trust Modification"
                        ]
                    },
                    {
                        "name": "Escape to Host",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Event Triggered Execution",
                        "subtechniques": [
                            "Change Default File Association",
                            "Screensaver",
                            "Windows Management Instrumentation Event Subscription",
                            "Unix Shell Configuration Modification",
                            "Trap",
                            "LC_LOAD_DYLIB Addition",
                            "Netsh Helper DLL",
                            "Accessibility Features",
                            "AppCert DLLs",
                            "AppInit DLLs",
                            "Application Shimming",
                            "Image File Execution Options Injection",
                            "PowerShell Profile",
                            "Emond",
                            "Component Object Model Hijacking",
                            "Installer Packages",
                            "Exploitation for Privilege Escalation"
                        ]
                    },
                    {
                        "name": "Exploitation for Privilege Escalation",
                        "subtechniques": []
                    },
                    {
                        "name": "Hijack Execution Flow",
                        "subtechniques": [
                            "DLL Search Order Hijacking",
                            "DLL Side-Loading",
                            "Dylib Hijacking",
                            "Executable Installer File Permissions Weakness",
                            "Dynamic Linker Hijacking",
                            "Path Interception by PATH Environment Variable",
                            "Path Interception by Search Order Hijacking",
                            "Path Interception by Unquoted Path",
                            "Services File Permissions Weakness",
                            "Services Registry Permissions Weakness",
                            "COR_PROFILER",
                            "KernelCallbackTable"
                        ]
                    },
                    {
                        "name": "Process Injection",
                        "subtechniques": [
                            "Dynamic-link Library Injection",
                            "Portable Executable Injection",
                            "Thread Execution Hijacking",
                            "Asynchronous Procedure Call",
                            "Thread Local Storage",
                            "Ptrace System Calls",
                            "Proc Memory",
                            "Extra Window Memory Injection",
                            "Process Hollowing",
                            "Process Doppelg\u00e4nging",
                            "VDSO Hijacking",
                            "ListPlanting",
                            "Reflective Code Loading",
                            "Rogue Domain Controller",
                            "Rootkit"
                        ]
                    },
                    {
                        "name": "Scheduled Task/Job",
                        "subtechniques": [
                            "At",
                            "Cron",
                            "Scheduled Task",
                            "Systemd Timers",
                            "Container Orchestration Job"
                        ]
                    },
                    {
                        "name": "Valid Accounts",
                        "subtechniques": [
                            "Default Accounts",
                            "Domain Accounts",
                            "Local Accounts",
                            "Cloud Accounts"
                        ]
                    }
                ]
            },
            {
                "name": "Defense Evasion",
                "techniques": [
                    {
                        "name": "Abuse Elevation Control Mechanism",
                        "subtechniques": [
                            "Setuid and Setgid",
                            "Bypass User Account Control",
                            "Sudo and Sudo Caching",
                            "Elevated Execution with Prompt"
                        ]
                    },
                    {
                        "name": "Access Token Manipulation",
                        "subtechniques": [
                            "Token Impersonation/Theft",
                            "Create Process with Token",
                            "Make and Impersonate Token",
                            "Parent PID Spoofing",
                            "SID-History Injection",
                            "BITS Jobs",
                            "Build Image on Host",
                            "Debugger Evasion",
                            "Deobfuscate/Decode Files or Information",
                            "Deploy Container",
                            "Direct Volume Access"
                        ]
                    },
                    {
                        "name": "BITS Jobs",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Build Image on Host",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Debugger Evasion",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Deobfuscate/Decode Files or Information",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Deploy Container",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Direct Volume Access",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Execution Guardrails",
                        "subtechniques": [
                            "Environmental Keying",
                            "Exploitation for Defense Evasion"
                        ]
                    },
                    {
                        "name": "Exploitation for Defense Evasion",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "File and Directory Permissions Modification",
                        "subtechniques": [
                            "Windows File and Directory Permissions Modification",
                            "Linux and Mac File and Directory Permissions Modification"
                        ]
                    },
                    {
                        "name": "Hide Artifacts",
                        "subtechniques": [
                            "Hidden Files and Directories",
                            "Hidden Users",
                            "Hidden Window",
                            "NTFS File Attributes",
                            "Hidden File System",
                            "Run Virtual Instance",
                            "VBA Stomping",
                            "Email Hiding Rules",
                            "Resource Forking",
                            "Process Argument Spoofing"
                        ]
                    },
                    {
                        "name": "Impair Defenses",
                        "subtechniques": [
                            "Disable or Modify Tools",
                            "Disable Windows Event Logging",
                            "Impair Command History Logging",
                            "Disable or Modify System Firewall",
                            "Indicator Blocking",
                            "Disable or Modify Cloud Firewall",
                            "Disable Cloud Logs",
                            "Safe Mode Boot",
                            "Downgrade Attack",
                            "Spoof Security Alerting"
                        ]
                    },
                    {
                        "name": "Indicator Removal",
                        "subtechniques": [
                            "Clear Windows Event Logs",
                            "Clear Linux or Mac System Logs",
                            "Clear Command History",
                            "File Deletion",
                            "Network Share Connection Removal",
                            "Timestomp",
                            "Clear Network Connection History and Configurations",
                            "Clear Mailbox Data",
                            "Clear Persistence",
                            "Indirect Command Execution"
                        ]
                    },
                    {
                        "name": "Indirect Command Execution",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Masquerading",
                        "subtechniques": [
                            "Invalid Code Signature",
                            "Right-to-Left Override",
                            "Rename System Utilities",
                            "Masquerade Task or Service",
                            "Match Legitimate Name or Location",
                            "Space after Filename",
                            "Double File Extension",
                            "Masquerade File Type"
                        ]
                    },
                    {
                        "name": "Modify Authentication Process",
                        "subtechniques": [
                            "Domain Controller Authentication",
                            "Password Filter DLL",
                            "Pluggable Authentication Modules",
                            "Network Device Authentication",
                            "Reversible Encryption",
                            "Multi-Factor Authentication",
                            "Hybrid Identity",
                            "Network Provider DLL",
                            "Multi-Factor Authentication Interception",
                            "Multi-Factor Authentication Request Generation",
                            "Network Sniffing"
                        ]
                    },
                    {
                        "name": "Modify Cloud Compute Infrastructure",
                        "subtechniques": [
                            "Create Snapshot",
                            "Create Cloud Instance",
                            "Delete Cloud Instance",
                            "Revert Cloud Instance",
                            "Modify Registry"
                        ]
                    },
                    {
                        "name": "Modify Registry",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Modify System Image",
                        "subtechniques": [
                            "Patch System Image",
                            "Downgrade System Image"
                        ]
                    },
                    {
                        "name": "Network Boundary Bridging",
                        "subtechniques": [
                            "Network Address Translation Traversal"
                        ]
                    },
                    {
                        "name": "Obfuscated Files or Information",
                        "subtechniques": [
                            "Binary Padding",
                            "Software Packing",
                            "Steganography",
                            "Compile After Delivery",
                            "Indicator Removal from Tools",
                            "HTML Smuggling",
                            "Dynamic API Resolution",
                            "Stripped Payloads",
                            "Embedded Payloads",
                            "Command Obfuscation",
                            "Fileless Storage",
                            "Plist File Modification"
                        ]
                    },
                    {
                        "name": "Plist File Modification",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Pre-OS Boot",
                        "subtechniques": [
                            "System Firmware",
                            "Component Firmware",
                            "Bootkit",
                            "ROMMONkit",
                            "TFTP Boot"
                        ]
                    },
                    {
                        "name": "Process Injection",
                        "subtechniques": [
                            "Dynamic-link Library Injection",
                            "Portable Executable Injection",
                            "Thread Execution Hijacking",
                            "Asynchronous Procedure Call",
                            "Thread Local Storage",
                            "Ptrace System Calls",
                            "Proc Memory",
                            "Extra Window Memory Injection",
                            "Process Hollowing",
                            "Process Doppelg\u00e4nging",
                            "VDSO Hijacking",
                            "ListPlanting",
                            "Reflective Code Loading",
                            "Rogue Domain Controller",
                            "Rootkit"
                        ]
                    },
                    {
                        "name": "Reflective Code Loading",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Rogue Domain Controller",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Rootkit",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Subvert Trust Controls",
                        "subtechniques": [
                            "Gatekeeper Bypass",
                            "Code Signing",
                            "SIP and Trust Provider Hijacking",
                            "Install Root Certificate",
                            "Mark-of-the-Web Bypass",
                            "Code Signing Policy Modification"
                        ]
                    },
                    {
                        "name": "System Binary Proxy Execution",
                        "subtechniques": [
                            "Compiled HTML File",
                            "Control Panel",
                            "CMSTP",
                            "InstallUtil",
                            "Mshta",
                            "Msiexec",
                            "Odbcconf",
                            "Regsvcs/Regasm",
                            "Regsvr32",
                            "Rundll32",
                            "Verclsid",
                            "Mavinject",
                            "MMC"
                        ]
                    },
                    {
                        "name": "System Script Proxy Execution",
                        "subtechniques": [
                            "PubPrn",
                            "Template Injection",
                            ""
                        ]
                    },
                    {
                        "name": "Template Injection",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Traffic Signaling",
                        "subtechniques": [
                            "Port Knocking",
                            "Socket Filters"
                        ]
                    },
                    {
                        "name": "Trusted Developer Utilities Proxy Execution",
                        "subtechniques": [
                            "MSBuild",
                            ""
                        ]
                    },
                    {
                        "name": "Unused/Unsupported Cloud Regions",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Use Alternate Authentication Material",
                        "subtechniques": [
                            "Application Access Token",
                            "Pass the Hash",
                            "Pass the Ticket",
                            "Web Session Cookie"
                        ]
                    },
                    {
                        "name": "Valid Accounts",
                        "subtechniques": [
                            "Default Accounts",
                            "Domain Accounts",
                            "Local Accounts",
                            "Cloud Accounts"
                        ]
                    },
                    {
                        "name": "Virtualization/Sandbox Evasion",
                        "subtechniques": [
                            "System Checks",
                            "User Activity Based Checks",
                            "Time Based Evasion"
                        ]
                    },
                    {
                        "name": "Weaken Encryption",
                        "subtechniques": [
                            "Reduce Key Space",
                            "Disable Crypto Hardware",
                            "XSL Script Processing"
                        ]
                    },
                    {
                        "name": "XSL Script Processing",
                        "subtechniques": []
                    }
                ]
            },
            {
                "name": "Credential Access",
                "techniques": [
                    {
                        "name": "Adversary-in-the-Middle",
                        "subtechniques": [
                            "LLMNR/NBT-NS Poisoning and SMB Relay",
                            "ARP Cache Poisoning",
                            "DHCP Spoofing"
                        ]
                    },
                    {
                        "name": "Brute Force",
                        "subtechniques": [
                            "Password Guessing",
                            "Password Cracking",
                            "Password Spraying",
                            "Credential Stuffing"
                        ]
                    },
                    {
                        "name": "Credentials from Password Stores",
                        "subtechniques": [
                            "Keychain",
                            "Securityd Memory",
                            "Credentials from Web Browsers",
                            "Windows Credential Manager",
                            "Password Managers",
                            "Exploitation for Credential Access",
                            "Forced Authentication"
                        ]
                    },
                    {
                        "name": "Exploitation for Credential Access",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Forced Authentication",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Forge Web Credentials",
                        "subtechniques": [
                            "Web Cookies",
                            "SAML Tokens"
                        ]
                    },
                    {
                        "name": "Input Capture",
                        "subtechniques": [
                            "Keylogging",
                            "GUI Input Capture",
                            "Web Portal Capture",
                            "Credential API Hooking"
                        ]
                    },
                    {
                        "name": "Modify Authentication Process",
                        "subtechniques": [
                            "Domain Controller Authentication",
                            "Password Filter DLL",
                            "Pluggable Authentication Modules",
                            "Network Device Authentication",
                            "Reversible Encryption",
                            "Multi-Factor Authentication",
                            "Hybrid Identity",
                            "Network Provider DLL"
                        ]
                    },
                    {
                        "name": "Multi-Factor Authentication Interception : None",
                        "subtechniques": []
                    },
                    {
                        "name": "Multi-Factor Authentication Request Generation : None",
                        "subtechniques": []
                    },
                    {
                        "name": "Network Sniffing: None",
                        "subtechniques": []
                    },
                    {
                        "name": "OS Credential Dumping",
                        "subtechniques": [
                            "LSASS Memory",
                            "Security Account Manager",
                            "NTDS",
                            "LSA Secrets",
                            "Cached Domain Credentials",
                            "DCSync",
                            "Proc Filesystem",
                            "/etc/passwd and /etc/shadow",
                            "Steal Application Access Token",
                            "Steal or Forge Authentication Certificates"
                        ]
                    },
                    {
                        "name": "Steal Application Access Token",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Steal or Forge Authentication Certificates",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Steal or Forge Kerberos Tickets",
                        "subtechniques": [
                            "Golden Ticket",
                            "Silver Ticket",
                            "Kerberoasting",
                            "AS-REP Roasting",
                            "Steal Web Session Cookie"
                        ]
                    },
                    {
                        "name": "Steal Web Session Cookie",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Unsecured Credentials",
                        "subtechniques": [
                            "Credentials In Files",
                            "Credentials in Registry",
                            "Bash History",
                            "Private Keys",
                            "Cloud Instance Metadata API",
                            "Group Policy Preferences",
                            "Container API",
                            "Chat Messages"
                        ]
                    }
                ]
            },
            {
                "name": "Discovery",
                "techniques": [
                    {
                        "name": "Account Discovery",
                        "subtechniques": [
                            "Local Account",
                            "Domain Account",
                            "Email Account",
                            "Cloud Account"
                        ]
                    },
                    {
                        "name": "Application Window Discovery",
                        "subtechniques": []
                    },
                    {
                        "name": "Browser Information Discovery",
                        "subtechniques": []
                    },
                    {
                        "name": "Cloud Infrastructure Discovery",
                        "subtechniques": []
                    },
                    {
                        "name": "Cloud Service Dashboard",
                        "subtechniques": []
                    },
                    {
                        "name": "Cloud Service Discovery",
                        "subtechniques": []
                    },
                    {
                        "name": "Cloud Storage Object Discovery",
                        "subtechniques": []
                    },
                    {
                        "name": "Container and Resource Discovery",
                        "subtechniques": []
                    },
                    {
                        "name": "Debugger Evasion",
                        "subtechniques": []
                    },
                    {
                        "name": "Device Driver Discovery",
                        "subtechniques": []
                    },
                    {
                        "name": "Domain Trust Discovery",
                        "subtechniques": []
                    },
                    {
                        "name": "File and Directory Discovery",
                        "subtechniques": []
                    },
                    {
                        "name": "Group Policy Discovery",
                        "subtechniques": []
                    },
                    {
                        "name": "Network Service Discovery",
                        "subtechniques": []
                    },
                    {
                        "name": "Network Share Discovery",
                        "subtechniques": []
                    },
                    {
                        "name": "Network Sniffing",
                        "subtechniques": []
                    },
                    {
                        "name": "Password Policy Discovery",
                        "subtechniques": []
                    },
                    {
                        "name": "Peripheral Device Discovery",
                        "subtechniques": []
                    },
                    {
                        "name": "Permission Groups Discovery",
                        "subtechniques": [
                            "Local Groups",
                            "Domain Groups",
                            "Cloud Groups"
                        ]
                    },
                    {
                        "name": "Process Discovery",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Query Registry",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Remote System Discovery",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Software Discovery",
                        "subtechniques": [
                            "Security Software Discovery"
                        ]
                    },
                    {
                        "name": "System Information Discovery",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "System Location Discovery",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "System Network Configuration Discovery",
                        "subtechniques": [
                            "Internet Connection Discovery"
                        ]
                    },
                    {
                        "name": "System Network Connections Discovery",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "System Owner/User Discovery",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "System Service Discovery",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "System Time Discovery",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Virtualization/Sandbox Evasion",
                        "subtechniques": [
                            "System Checks",
                            "User Activity Based Checks",
                            "Time Based Evasion"
                        ]
                    }
                ]
            },
            {
                "name": "Lateral Movement",
                "techniques": [
                    {
                        "name": "Exploitation of Remote Services",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Internal Spearphishing",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Lateral Tool Transfer",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Remote Service Session Hijacking",
                        "subtechniques": [
                            "SSH Hijacking",
                            "RDP Hijacking"
                        ]
                    },
                    {
                        "name": "Remote Services",
                        "subtechniques": [
                            "Remote Desktop Protocol",
                            "SMB/Windows Admin Shares",
                            "Distributed Component Object Model",
                            "SSH",
                            "VNC",
                            "Windows Remote Management",
                            "Cloud Services"
                        ]
                    },
                    {
                        "name": "Replication Through Removable Media",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Software Deployment Tools",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Taint Shared Content",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Use Alternate Authentication Material",
                        "subtechniques": [
                            "Application Access Token",
                            "Pass the Hash",
                            "Pass the Ticket",
                            "Web Session Cookie"
                        ]
                    }
                ]
            },
            {
                "name": "Collection",
                "techniques": [
                    {
                        "name": "Adversary-in-the-Middle",
                        "subtechniques": [
                            "LLMNR/NBT-NS Poisoning and SMB Relay",
                            "ARP Cache Poisoning",
                            "DHCP Spoofing"
                        ]
                    },
                    {
                        "name": "Archive Collected Data",
                        "subtechniques": [
                            "Archive via Utility",
                            "Archive via Library",
                            "Archive via Custom Method"
                        ]
                    },
                    {
                        "name": "Audio Capture",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Automated Collection",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Browser Session Hijacking",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Clipboard Data",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Data from Cloud Storage",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Data from Configuration Repository",
                        "subtechniques": [
                            "SNMP (MIB Dump)",
                            "Network Device Configuration Dump"
                        ]
                    },
                    {
                        "name": "Data from Information Repositories",
                        "subtechniques": [
                            "Confluence",
                            "Sharepoint",
                            "Code Repositories"
                        ]
                    },
                    {
                        "name": "Data from Local System",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Data from Network Shared Drive",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Data from Removable Media",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Data Staged",
                        "subtechniques": [
                            "Local Data Staging",
                            "Remote Data Staging"
                        ]
                    },
                    {
                        "name": "Email Collection",
                        "subtechniques": [
                            "Local Email Collection",
                            "Remote Email Collection",
                            "Email Forwarding Rule"
                        ]
                    },
                    {
                        "name": "Input Capture",
                        "subtechniques": [
                            "Keylogging",
                            "GUI Input Capture",
                            "Web Portal Capture",
                            "Credential API Hooking"
                        ]
                    },
                    {
                        "name": "Screen Capture",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Video Capture",
                        "subtechniques": [
                            "None"
                        ]
                    }
                ]
            },
            {
                "name": "Command and Control",
                "techniques": [
                    {
                        "name": "Application Layer Protocol",
                        "subtechniques": [
                            "Web Protocols",
                            "File Transfer Protocols",
                            "Mail Protocols",
                            "DNS"
                        ]
                    },
                    {
                        "name": "Communication Through Removable Media",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Data Encoding",
                        "subtechniques": [
                            "Standard Encoding",
                            "Non-Standard Encoding"
                        ]
                    },
                    {
                        "name": "Data Obfuscation",
                        "subtechniques": [
                            "Junk Data",
                            "Steganography",
                            "Protocol Impersonation"
                        ]
                    },
                    {
                        "name": "Dynamic Resolution",
                        "subtechniques": [
                            "Fast Flux DNS",
                            "Domain Generation Algorithms",
                            "DNS Calculation"
                        ]
                    },
                    {
                        "name": "Encrypted Channel",
                        "subtechniques": [
                            "Symmetric Cryptography",
                            "Asymmetric Cryptography"
                        ]
                    },
                    {
                        "name": "Fallback Channels",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Ingress Tool Transfer",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Multi-Stage Channels",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Non-Application Layer Protocol",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Non-Standard Port",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Protocol Tunneling",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Proxy",
                        "subtechniques": [
                            "Internal Proxy",
                            "External Proxy",
                            "Multi-hop Proxy",
                            "Domain Fronting"
                        ]
                    },
                    {
                        "name": "Remote Access Software",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Traffic Signaling",
                        "subtechniques": [
                            "Port Knocking",
                            "Socket Filters"
                        ]
                    },
                    {
                        "name": "Web Service",
                        "subtechniques": [
                            "Dead Drop Resolver",
                            "Bidirectional Communication",
                            "One-Way Communication"
                        ]
                    }
                ]
            },
            {
                "name": "Exfiltration",
                "techniques": [
                    {
                        "name": "Automated Exfiltration",
                        "subtechniques": [
                            "Traffic Duplication"
                        ]
                    },
                    {
                        "name": "Data Transfer Size Limits",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Exfiltration Over Alternative Protocol",
                        "subtechniques": [
                            "Exfiltration Over Symmetric Encrypted Non-C2 Protocol",
                            "Exfiltration Over Asymmetric Encrypted Non-C2 Protocol",
                            "Exfiltration Over Unencrypted Non-C2 Protocol"
                        ]
                    },
                    {
                        "name": "Exfiltration Over C2 Channel",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Exfiltration Over Other Network Medium",
                        "subtechniques": [
                            "Exfiltration Over Bluetooth"
                        ]
                    },
                    {
                        "name": "Exfiltration Over Physical Medium",
                        "subtechniques": [
                            "Exfiltration over USB"
                        ]
                    },
                    {
                        "name": "Exfiltration Over Web Service",
                        "subtechniques": [
                            "Exfiltration to Code Repository",
                            "Exfiltration to Cloud Storage",
                            "Exfiltration to Text Storage Sites"
                        ]
                    },
                    {
                        "name": "Scheduled Transfer",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Transfer Data to Cloud Account",
                        "subtechniques": [
                            "None"
                        ]
                    }
                ]
            },
            {
                "name": "Impact",
                "techniques": [
                    {
                        "name": "Account Access Removal",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Data Destruction",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Data Encrypted for Impact",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Data Manipulation",
                        "subtechniques": [
                            "Stored Data Manipulation",
                            "Transmitted Data Manipulation",
                            "Runtime Data Manipulation"
                        ]
                    },
                    {
                        "name": "Defacement",
                        "subtechniques": [
                            "Internal Defacement",
                            "External Defacement"
                        ]
                    },
                    {
                        "name": "Disk Wipe",
                        "subtechniques": [
                            "Disk Content Wipe",
                            "Disk Structure Wipe"
                        ]
                    },
                    {
                        "name": "Endpoint Denial of Service",
                        "subtechniques": [
                            "OS Exhaustion Flood",
                            "Service Exhaustion Flood",
                            "Application Exhaustion Flood",
                            "Application or System Exploitation"
                        ]
                    },
                    {
                        "name": "Firmware Corruption",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Inhibit System Recovery",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Network Denial of Service",
                        "subtechniques": [
                            "Direct Network Flood",
                            "Reflection Amplification",
                            "Resource Hijacking"
                        ]
                    },
                    {
                        "name": "Resource Hijacking",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "Service Stop",
                        "subtechniques": [
                            "None"
                        ]
                    },
                    {
                        "name": "System Shutdown/Reboot",
                        "subtechniques": [
                            "None"
                        ]
                    }
                ]
            }
        ];
        

// Define the margins and dimensions of the SVG container
var margin = {top: 150, right: 50, bottom: 150, left: 50},
    width = 6700 - margin.left - margin.right,
    height = 17500 - margin.top - margin.bottom;

// Define the number of rows and columns
var cols = tactics.length;  // One for each ATT&CK tactic

// Define the size of each cell
 var cellSize = width / cols;

// Define the column names
var colNames = ["Reconnaissance", "Resource Development", "Initial Access", "Execution", "Persistence", "Privilege Escalation", "Defense Evasion", "Credential Access", "Discovery", "Lateral Movement", "Collection", "Command and Control", "Exfiltration", "Impact"];

var zoom = d3.zoom()
    .scaleExtent([1, 10])
    .on("zoom", function(event) {
        svgGroup.attr("transform", event.transform);
    });

// Create the SVG container
var svg = d3.select("#matrix").append("svg")
    .attr("preserveAspectRatio", "xMinYMin meet")  // Preserve the aspect ratio
    .attr("viewBox", "0 0 " + (width + margin.left + margin.right) + " " + (height + margin.top + margin.bottom))  // Set the viewBox
    .call(zoom)  // Attach zoom behavior to the SVG container
    .append("g");

var svgGroup = svg.append("g")
.attr("transform", "translate(" + margin.left + "," + margin.top + ")");


// Add column headers
svgGroup.selectAll(".colName")  // use class selector instead of element selector
    .data(colNames)
    .enter().append("text")
    .attr("class", "colName")  // assign class to these text elements
    .attr("x", function(d, i) { return i * cellSize; })
    .attr("y", 0)
    .attr("dy", "-.2em")  // Offset the text up by 1em
    .style("fill", "var(--text-color)")
    .style("font-size", "5.5em")  // Make the text larger
    .style("font-weight", "bold")
    .text(function(d) { return d; })
    .attr("transform", function(d, i) {
        return "rotate(-30 " + (i * cellSize) + ",0)"
    });

// Title
svgGroup.append("text")
    .attr("class", "title")  // assign class to the title
    .attr("id", "matrixTitle")
    .attr("x", width / 2)
    .attr("y", -100)
    .attr("dy", "-5em")  // Offset the text up by 2em
    .style("text-anchor", "middle")  // Center the text
    .style("font-size", "6em")  // Make the text larger
    .text("ATT&CK Matrix")
    .style("text-decoration", "underline")  
    .style("fill", "var(--text-color)")

var showSubtechniques = false;

// Function to update the display based on the current state
function updateDisplay() {
    // Remove all existing cells and text
    svgGroup.selectAll("rect").remove();
    svgGroup.selectAll(".dynamicText").remove();  // use class selector
    svgGroup.selectAll("foreignObject").remove();

    // Redraw the cells and text
    tactics.forEach(function(tactic, i) {
        var techniquesAndSubtechniques = [];
        tactic.techniques.forEach(function(technique) {
            techniquesAndSubtechniques.push(technique);
            if (showSubtechniques && technique.subtechniques) {
                technique.subtechniques.forEach(function(subtechnique) {
                    techniquesAndSubtechniques.push({name: subtechnique, isSubtechnique: true});
                });
            }
        });

        // When drawing the cells
        var cells = svgGroup.selectAll("rect" + i)
            .data(techniquesAndSubtechniques)
            .enter().append("rect")
            .attr("class", function(d) {
            var tacticClass = tactic.name.replace(/ /g, '_');
            var techniqueClass = d.name.replace(/ /g, '_').replace(/\//g, '-');
            return tacticClass + " " + techniqueClass
            })
            .attr("width", function(d) { 
                return (d.isSubtechnique ? cellSize : cellSize); // removing division by 2 for subtechnique width
            })
            .attr("height", cellSize)
            .attr("x", function(d) { 
                return (i + (d.isSubtechnique ? 0.5 : 0)) * cellSize - (d.isSubtechnique ? 235 : 0); // adjust left for subtechniques
            })
            .attr("y", function(d, j) { 
                return j * cellSize; 
            })
            .style("stroke", "#aaa")
            .style("fill", function(d, j) { 
                if (d.isSubtechnique) {
                    return "orange";
                } else {
                    return "black";
                }
            });

        cells.append("text")
            .attr("class", "dynamicText")  // assign class to these text elements
            .attr("x", i * cellSize + cellSize / 2)
            .attr("y", function(d, j) { return (j + 1) * cellSize + cellSize / 2; })  
            .attr("dy", ".35em")
            .style("text-anchor", "middle")
            .style("font-size", cellSize / 10 + "px")
            .style("fill", 'white')
            .text(function(d) { return d.name + (d.samples ? ': ' + d.samples.join(', ') : ''); });

        svgGroup.selectAll("foreignObject" + i)
            .data(techniquesAndSubtechniques)  
            .enter().append("foreignObject")
            .attr("x", function(d) { 
                return (i + (d.isSubtechnique ? 0.5 : 0)) * cellSize + 0.1 * cellSize - (d.isSubtechnique ? 235 : 0); // adjust left for subtechniques
            })            
            .attr("y", function(d, j) { return j * cellSize + 0.1 * cellSize; })  
            .attr("width", cellSize * 0.8)
            .attr("height", cellSize * 0.8)
            .attr("class", function(d) { return d.isSubtechnique ? "subtechnique" : "technique"; })  
            .append("xhtml:body")
            .style("font-size", cellSize / 8.5 + "px")
            .style("background", "transparent")
            .style("margin", "0px")
            .style("word-wrap", "break-word")
            .style("overflow", "visible")
            .style("white-space", "normal")
            .style("color", function(d) { return d.isSubtechnique ? "black" : "white"; })
            .html(function(d) { return d.name + (d.samples ? ': ' + d.samples.join(', ') : ''); 
        });
}
    )};

///////////////////////////////////////////////////////////////////
// Parse JSON data - Pt 2

// Fetch the JSON data from the server
fetch('/daily_threats.json')
    .then(response => response.json())  // Parse the JSON text to JavaScript object
    .then(threatData => {
        // Get the dropdown element
        var dropdown = document.getElementById('malwareDropdown');

        // Create a dictionary to count the occurrences of each sample_name
        var sampleCounts = {};

        // Iterate over each object in the data
        threatData.forEach(function(threat) {
            // If the sample_name is 'None', replace it with 'Unknown'
            if (threat.sample_name === 'None') {
                threat.sample_name = 'Unknown';
            }

            // Create a unique key for the sample_name and vendor
            var sampleVendorKey = threat.sample_name + ' - ' + threat.vendor;

            // If this sample_name and vendor combination has already been seen, increment its count
            if (sampleCounts[sampleVendorKey]) {
                sampleCounts[sampleVendorKey]++;
            } 
            // If it's the first time we see this sample_name and vendor combination, initialize its count to 1
            else {
                sampleCounts[sampleVendorKey] = 1;
            }

            // Create a new option element
            var option = document.createElement('option');
            option.value = threat.sample_name;
            option.text = threat.sample_name + ' - ' + threat.vendor + ' - TTP Hit #' + sampleCounts[sampleVendorKey];

            // Add the option to the dropdown
            dropdown.add(option);
        });

// When the selected option changes
dropdown.onchange = function() {
    // Get the selected malware sample
    var selectedSample = dropdown.value.split(' - ')[0];

    // Reset the colors of all the cells to their original state
    svgGroup.selectAll("rect")
    .style("fill", function(d) { 
        if (d.isSubtechnique) {
            var grayLevel = d.subtechniques ? Math.min(100 + 10 * d.subtechniques.length, 200) : 100;
            return "rgb(" + grayLevel + "," + grayLevel + "," + grayLevel + ")";
        } else {
            return "black";
        }
    });
    

    // Get the Show Subtechniques button
    var showSubtechniquesButton = document.getElementById('toggleSubtechniques');
    
    // Programmatically click the Show Subtechniques button
    showSubtechniquesButton.click();

    // Iterate over the threat data
 // Iterate over the threat data
// Iterate over the threat data
threatData.forEach(function(threat) {
    // If the sample name matches the selected sample
    if (threat.sample_name === selectedSample) {
        // Find the corresponding tactic and technique in the matrix
        var tactic = tactics.find(function(t) { return t.name == threat.tactic_name; });
        if (tactic) {
            var technique = tactic.techniques.find(function(t) { return t.name.split('.')[0] == threat.technique_name.split('.')[0]; });
            if (technique) {
                var subtechnique;
                if (threat.technique_id.includes('.')) {
                    var subtechniqueIndex = Number(threat.technique_id.split('.')[1]) - 1; // subtract 1 because arrays are 0-indexed
                    subtechnique = technique.subtechniques[subtechniqueIndex];
                }
                // Change the color of the corresponding cell
                var cell;
                if (subtechnique) {
                    cell = svgGroup.select("rect." + tactic.name.replace(/ /g, '_') + "." + technique.name.replace(/ /g, '_').replace(/\//g, '-') + "." + subtechnique.replace(/ /g, '_'));
                    cell.style("fill", "orange");  // Subtechniques are colored orange
                } else {
                    cell = svgGroup.select("rect." + tactic.name.replace(/ /g, '_') + "." + technique.name.replace(/ /g, '_').replace(/\//g, '-'));
                    cell.style("fill", "red");  // Techniques are colored red
                }
            }
        }
    }
})
}
    })
    .catch(error => console.error('Error:', error));  // Log any error occurred during the fetch


// Initial display
updateDisplay();

// Button to toggle the display of sub-techniques
d3.select("#toggleSubtechniques").on("click", function() {
    showSubtechniques = !showSubtechniques;
    updateDisplay();
    this.textContent = showSubtechniques ? "Hide Subtechniques" : "Show Subtechniques";
});      
        
d3.select("#matrix svg").style("width", "100%")

function zoomed() {
    // Get the new scale and translate parameters
    var transform = d3.event.transform;

    // Apply these to the SVG container
    svgGroup.attr("transform", transform);
}

var zoomLevel = 1;  // Change this to the desired zoom level
var titleBBox = d3.select("#matrixTitle").node().getBBox();
var titleX = titleBBox.x;
var titleY = titleBBox.y;

d3.select("#spring").on("click", function() {
    // Set the zoom and pan to the desired values
    svg.call(zoom.transform, d3.zoomIdentity.translate(titleX, titleY).scale(zoomLevel));
});

var resetViewButton = document.getElementById('resetViewButton');
resetViewButton.addEventListener('click', function() {
    svg.transition()
       .duration(750)
       .call(zoom.transform, d3.zoomIdentity);
});

//////////////////////////////////////////////////////////////////////////////
//Save function - pt 3
var downloadButton = document.getElementById('downloadButton');

downloadButton.addEventListener('click', function() {
    var svgElement = document.querySelector('#matrix svg');
    var dropdown = document.getElementById('malwareDropdown');
    var selectedOptionText = dropdown.options[dropdown.selectedIndex].text;

    // Get the bounding box of the SVG content
    var bbox = svgElement.getBBox();

    // Add some padding to the bounding box dimensions
    var padding = 100; // Increased padding
    bbox.x -= padding;
    bbox.y -= padding;
    bbox.width += 2 * padding;
    bbox.height += 2 * padding;

    // Set the viewBox attribute to the bounding box dimensions
    svgElement.setAttribute('viewBox', bbox.x + ' ' + bbox.y + ' ' + bbox.width + ' ' + bbox.height);

    var filename = selectedOptionText.replace(/[^a-zA-Z0-9]/g, '_') + '.svg';
    var svgData = new XMLSerializer().serializeToString(svgElement);

    var blob = new Blob([svgData], {type: "image/svg+xml;charset=utf-8"});
    var url = URL.createObjectURL(blob);

    var link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
});

/////////////////////////////////////////////////////////////////////////////
/// Download report - Pt 4
var threatData

//ANOTHER FETCH CALL? 
fetch('/daily_threats.json')
    .then(response => response.json())  // Parse the JSON text to JavaScript object
    .then(data => {
        threatData = data;
        
        // Rest of your fetch code...
    })
    .catch(error => console.error('Error:', error));  // Log any error occurred during the fetch

// Get the download report button element
var downloadReportButton = document.getElementById('downloadReportButton');

// Add click event listener
downloadReportButton.addEventListener('click', function() {
    var dropdown = document.getElementById('malwareDropdown');
    var selectedSample = dropdown.value.split(' - ')[0];

    // Generate the report
    var report = generateReport(selectedSample);

    // Create a blob from the report string
    var blob = new Blob([report], {type: "text/plain;charset=utf-8"});
    var url = URL.createObjectURL(blob);

    // Create a link for the user to download the report
    var link = document.createElement('a');
    link.href = url;
    link.download = selectedSample.replace(/[^a-zA-Z0-9]/g, '_') + '_report.txt';
    link.click();
});


var foundSubtechnique = false;

// Function to generate a report for a given malware sample
function generateReport(sampleName) {
    // Initialize a Set for unique tactics and techniques
    var uniqueTactics = new Set();
    var uniqueTechniques = new Set();
    var vendors = new Set();

    // Initialize a dictionary to count the TTP hits for each vendor
    var vendorTTPCounts = {};

    // Iterate over the threat data
    threatData.forEach(function(threat) {
        // If the sample name matches the selected sample
        if (threat.sample_name === sampleName) {
            uniqueTactics.add(threat.tactic_name);
            if (threat.technique_id.includes('.')) {
                // If the technique_id includes a '.', it's a subtechnique
                uniqueTechniques.add(threat.technique_name + ' (Subtechnique of ' + threat.technique_id.split('.')[0] + ')');
            } else {
                uniqueTechniques.add(threat.technique_name);
            }
            vendors.add(threat.vendor);

            // If this vendor has already been seen for this sample, increment its TTP hit count
            if (vendorTTPCounts[threat.vendor]) {
                vendorTTPCounts[threat.vendor]++;
            } 
            // If it's the first time we see this vendor for this sample, initialize its TTP hit count to 1
            else {
                vendorTTPCounts[threat.vendor] = 1;
            }
        }
    });

    var report = 'Sample Name: ' + sampleName + '\n';
    report += 'Number of unique tactics: ' + uniqueTactics.size + '\n';
    report += 'Number of unique techniques (including subtechniques): ' + uniqueTechniques.size + '\n';
    report += 'Vendors: ' + Array.from(vendors).join(', ') + '\n';
    report += 'Hits:\n';

    // Iterate over the threat data
    threatData.forEach(function(threat) {
        // If the sample name matches the selected sample
        if (threat.sample_name === sampleName) {
            var hitLine = '- Tactic: ' + threat.tactic_name + ', Technique: ' + threat.technique_name;
            if (threat.technique_id.includes('.')) {
                // If the technique_id includes a '.', it's a subtechnique
                hitLine += ', Subtechnique: ' + threat.technique_name.split(' (Subtechnique of ')[0];
            }
            // Append the vendor information and TTP hit count to the hit line
            hitLine += ', Vendor: ' + threat.vendor + ' (TTP Hit #' + vendorTTPCounts[threat.vendor] + ')';
            report += hitLine + '\n';
        }
    });

    return report;
}
