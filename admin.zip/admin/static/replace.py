import json

def remove_text():
    with open('report.json', 'r') as file:
        data = file.read()

    text_to_remove = '''{
    "query_status": "ok",
    "data": ['''
    end_text_to_remove = '''}
]'''
    trailing_brace = '}'

    modified_data = data.replace(text_to_remove, '')
    intermediate_data = modified_data.replace(end_text_to_remove, '')
    final_data = intermediate_data.rstrip(trailing_brace)

    # Add a single [ at the start of the file
    final_data = '[' + final_data

    with open('formatted_report.json', 'w') as file:
        file.write(final_data)

if __name__ == "__main__":
    remove_text()
