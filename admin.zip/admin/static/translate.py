import json

def extract_info(json_data):
    results = {}
    for item in json_data:
        if 'data' in item:  # Check if 'data' key exists
            sample_name = item['data'].get('sample_name', '')  # Use get() method to avoid KeyError
            for vendor, vendor_data in item['data'].items():
                if vendor != 'sample_name' and isinstance(vendor_data, dict):
                    for tactic in vendor_data.get('tactics', []):
                        tactic_name = tactic['name']
                        tactic_id = tactic['id']
                        for technique in tactic['techniques']:
                            technique_name = technique['name']
                            technique_id = technique['id']
                            for signature in technique['signatures']:
                                signature_desc = signature['description']
                                key = (sample_name, vendor, tactic_name, tactic_id, technique_name, technique_id)
                                if key in results:
                                    results[key].add(signature_desc)  # Add signature_desc to the set
                                else:
                                    results[key] = {signature_desc}  # Initialize a set with signature_desc
    return results

# Load your JSON data
with open('threats.json') as f:
    data = json.load(f)

# Extract the information
extracted_info = extract_info(data)

# Convert the dictionary to a list of dictionaries for JSON serialization
output = [{'sample_name': key[0], 'vendor': key[1], 'tactic_name': key[2], 'tactic_id': key[3], 'technique_name': key[4], 'technique_id': key[5], 'signature_desc': list(value)} for key, value in extracted_info.items()]

# Write the extracted information to new file
with open('daily_threats.json', 'w') as f:
    json.dump(output, f, indent=4)
