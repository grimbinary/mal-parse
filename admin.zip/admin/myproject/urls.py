from django.contrib import admin
from django.urls import path, include
from django.views.generic import RedirectView
from django.contrib.auth import views as auth_views
from myproject.api import views 


urlpatterns = [
    path('', RedirectView.as_view(url='/login/')),
    path('login/', auth_views.LoginView.as_view(template_name='admin/login.html'), name='login'),
    path('admin/', admin.site.urls),
    path('reports/', views.reports, name='reports'),
    path('formatted_report.json', views.formatted_report, name='formatted_report'), 
    path('daily_threats.json', views.threats, name='daily_threats.json'),
    path('techniques.json', views.techniques),
]