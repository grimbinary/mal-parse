from rest_framework import generics
from .models import Report
from .serializers import ReportSerializer
from django.shortcuts import render
from .models import Report
from django.core import serializers
from django.http import JsonResponse
from django.http import FileResponse
from django.http import HttpResponse


class ReportList(generics.ListCreateAPIView):
    queryset = Report.objects.all()
    serializer_class = ReportSerializer

def reports(request):
    reports = Report.objects.all()  
    data = serializers.serialize('json', reports)
    return render(request, 'api/report_list.html', {'reports': reports})

def formatted_report(request):
    reports = Report.objects.all()

    formatted_data = format_report_data(reports) 
    return JsonResponse(formatted_data, safe=False)

def format_report_data(reports):
    formatted_data = []
    for report in reports:
        formatted_report = {
            'file_size': report.file_size,
            'file_type': report.file_type,
            'sha256_hash': report.sha256_hash,
            'md5_hash': report.md5_hash,
            'first_seen': report.first_seen.isoformat() if report.first_seen else None,
            'last_seen': report.last_seen.isoformat() if report.last_seen else None,
            'reporter': report.reporter,
            'origin_country': report.origin_country,
            'signature': report.signature,
            'delivery_method': report.delivery_method,
            'comments': report.comments,
            'vendor_intel': format_vendor_intel(report.vendor_intel.all()),
            
        }
        formatted_data.append(formatted_report)
    return formatted_data

def format_vendor_intel(vendor_intel_instances):
    vendor_intel_data = []
    for instance in vendor_intel_instances:
        vendor_data = {
            'vendor_name': instance.vendor_name,
            'any_run': instance.any_run,
            'cert_pl_mwdb': instance.cert_pl_mwdb,
            'vxcube': instance.vxcube,
            'intezer': instance.intezer,
            'inquest': instance.inquest,
            'triage': instance.triage,
            'reversinglabs': instance.reversinglabs,
            'spamhaus_hbl': instance.spamhaus_hbl,
            'unpacme': instance.unpacme,
            'filescan_io': instance.filescan_io,
            
        }
        vendor_intel_data.append(vendor_data)
    return vendor_intel_data

def threats(request):
    file_path = 'static/daily_threats.json'
    return FileResponse(open(file_path, 'rb'), content_type='application/json')


def techniques(request):
    file_path = 'static/techniques.json'
    return FileResponse(open(file_path, 'rb'), content_type='application/json')
