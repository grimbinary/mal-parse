from django.core.management.base import BaseCommand
from myproject.api.models import Report, Intelligence, VendorIntel, FileInformation, YARARule, OLEInformation
from django.utils.dateparse import parse_datetime

import json

class Command(BaseCommand):
    help = 'Loads data from formatted_report.json into our Report model'

    def handle(self, *args, **kwargs):
        with open('formatted_report.json') as f:
            data = json.load(f)


        for report_data in data:
            if 'last_seen' in report_data and report_data['last_seen'] is not None:
                report_data['last_seen'] = parse_datetime(report_data['last_seen'])
            
            if 'comment' in report_data:
                report_data['comment'] = report_data['comment']

            if report_data.get('file_size') is None:
                continue

            intelligence_data = report_data.pop('intelligence', None)
            if intelligence_data is not None:
                intelligence = Intelligence.objects.create(**intelligence_data)
                report_data['intelligence'] = intelligence

            file_information_data = report_data.pop('file_information', [])
            if file_information_data is not None:
                file_information_instances = [FileInformation.objects.create(**info) for info in file_information_data]
            else:
                file_information_instances = []
            
            yara_rules_data = report_data.pop('yara_rules', [])
            yara_rules_instances = [YARARule.objects.create(**rule) for rule in yara_rules_data] if yara_rules_data is not None else []

            ole_information_data = report_data.pop('ole_information', [])
            ole_information_instances = [OLEInformation.objects.create(**info) for info in ole_information_data] if ole_information_data is not None else []

            vendor_intel_data = report_data.pop('vendor_intel', None)
            vendor_intel_instances = []

            if vendor_intel_data is not None:
                for vendor_name, vendor_data in vendor_intel_data.items():
                    vendor_intel_instance = VendorIntel.objects.create(
                        vendor_name=vendor_name,
                        any_run=vendor_data if vendor_name == 'ANY.RUN' else None,
                        cert_pl_mwdb=vendor_data if vendor_name == 'CERT-PL_MWDB' else None,
                        vxcube=vendor_data if vendor_name == 'vxCube' else None,
                        intezer=vendor_data if vendor_name == 'Intezer' else None,
                        inquest=vendor_data if vendor_name == 'InQuest' else None,
                        triage=vendor_data if vendor_name == 'Triage' else None,
                        reversinglabs=vendor_data if vendor_name == 'ReversingLabs' else None,
                        spamhaus_hbl=vendor_data if vendor_name == 'Spamhaus_HBL' else None,
                        unpacme=vendor_data if vendor_name == 'UnpacMe' else None,
                        filescan_io=vendor_data if vendor_name == 'FileScan-IO' else None,
                    )
                    vendor_intel_instances.append(vendor_intel_instance)

            unnecessary_fields = ['sha3_384_hash', 'sha1_hash', 'anonymous', 'imphash', 'tlsh', 'telfhash', 'gimphash', 'ssdeep', 'dhash_icon', 'archive_pw', 'code_sign']
            for field in unnecessary_fields:
                if field in report_data:
                    report_data.pop(field)

            # add default value for delivery_method if it is not present
            if 'delivery_method' not in report_data:
                report_data['delivery_method'] = 'Unknown'

            # create Report instance
            print(report_data)

            report = Report.objects.create(**report_data)

            # Add file_information, yara_rules, ole_information and vendor_intel instances to report
            if file_information_instances:
                report.file_information.set(file_information_instances)
            if yara_rules_instances:
                report.yara_rules.set(yara_rules_instances)
            if ole_information_instances:
                report.ole_information.set(ole_information_instances)
            if vendor_intel_instances:
                report.vendor_intel.set(vendor_intel_instances)


        self.stdout.write(self.style.SUCCESS('Data loaded successfully'))
