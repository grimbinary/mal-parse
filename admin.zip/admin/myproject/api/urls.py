from django.urls import path
from . import views

urlpatterns = [
    path('reports/', views.ReportList.as_view(), name='api_report_list'),
    path('formatted_report.json', views.formatted_report, name='formatted_report'),
    
]
