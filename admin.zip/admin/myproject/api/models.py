from django.db import models
from django.contrib.postgres.fields import JSONField  


class Report(models.Model):
    sha256_hash = models.CharField(max_length=64)
    md5_hash = models.CharField(max_length=32)
    first_seen = models.DateTimeField(null=True)
    last_seen = models.DateTimeField(null=True)
    file_name = models.CharField(max_length=255)
    file_size = models.IntegerField(null=True)
    file_type_mime = models.CharField(max_length=255)
    file_type = models.CharField(max_length=255)
    reporter = models.CharField(max_length=255)
    origin_country = models.CharField(max_length=2)
    signature = models.TextField(null=True)
    tags = models.TextField()
    comment = models.TextField(blank=True, null=True)
    delivery_method = models.CharField(max_length=255, null=True)
    intelligence = models.ForeignKey('Intelligence', on_delete=models.CASCADE, null=True)
    file_information = models.ManyToManyField('FileInformation')
    ole_information = models.ManyToManyField('OLEInformation', blank=True)
    yara_rules = models.ManyToManyField('YARARule', blank=True)
    vendor_intel = models.ManyToManyField('VendorIntel', blank=True, related_name='related_reports')
    comments = models.TextField(null=True)


class Intelligence(models.Model):
    clamav = models.CharField(max_length=255, null=True)
    downloads = models.CharField(max_length=255, null=True)
    uploads = models.CharField(max_length=255, null=True)
    mail = models.CharField(max_length=255, null=True)

class FileInformation(models.Model):
    context = models.CharField(max_length=255)
    value = models.CharField(max_length=255)

class OLEInformation(models.Model):
    indicator = models.CharField(max_length=255)
    value = models.CharField(max_length=255)

class YARARule(models.Model):
    rule_name = models.CharField(max_length=255)
    author = models.CharField(max_length=255, null=True)
    description = models.CharField(max_length=255, null=True)
    reference = models.CharField(max_length=255, null=True)
    
class VendorIntel(models.Model):
    vendor_name = models.CharField(max_length=255)
    any_run = models.JSONField(blank=True, null=True)
    cert_pl_mwdb = models.JSONField(blank=True, null=True)
    vxcube = models.JSONField(blank=True, null=True)
    intezer = models.JSONField(blank=True, null=True)
    inquest = models.JSONField(blank=True, null=True)
    triage = models.JSONField(blank=True, null=True)
    reversinglabs = models.JSONField(blank=True, null=True)
    spamhaus_hbl = models.JSONField(blank=True, null=True)
    unpacme = models.JSONField(blank=True, null=True)
    filescan_io = models.JSONField(blank=True, null=True)
    vmray = models.JSONField(blank=True, null=True) 
    spamhaus_hbl = models.JSONField(blank=True, null=True) 
    unpacme = models.JSONField(blank=True, null=True) 

    def __str__(self):
        return self.vendor_name