# __   __  _______  ___             _______  _______  ______    _______  _______ 
#|  |_|  ||   _   ||   |           |       ||   _   ||    _ |  |       ||       |
#|       ||  |_|  ||   |     ____  |    _  ||  |_|  ||   | ||  |  _____||    ___|
#|       ||       ||   |    |____| |   |_| ||       ||   |_||_ | |_____ |   |___ 
#|       ||       ||   |___        |    ___||       ||    __  ||_____  ||    ___|
#| ||_|| ||   _   ||       |       |   |    |   _   ||   |  | | _____| ||   |___ 
#|_|   |_||__| |__||_______|       |___|    |__| |__||___|  |_||_______||_______|

#####################################################################################################################
# Author: Grim : @grimbinary                                                                                        #
# Date: 2023-08-05                                                                                                  # 
# Purpose: To make open source malware detection and analysis more portarable and easy                              #
# To Do:                                                                                                            #
# 1) Integrate malware sandbox engine                                                                               #   
#                                                                                                                   #
#####################################################################################################################

import subprocess
import time
import zipfile
from colorama import Fore
import requests
import argparse
import json
import pyzipper
import urllib3
import openai
import shutil
import re
import hashlib
import uuid
import sys
import signal
from halo import Halo
from tqdm import tqdm
import configparser
from datetime import datetime
from subprocess import run
from elasticsearch import Elasticsearch
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError
from discord_webhook import DiscordWebhook
import os

# Color Codes
gold = Fore.YELLOW
green = Fore.GREEN
white = Fore.WHITE

def execute_command(command):
    subprocess.run(command, shell=True)

def execute_admin_command(command):
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
    stdout, stderr = process.communicate()

    if process.returncode != 0:
        print(f'Error executing command: {command}\n{stderr.decode()}')
    else:
        print(stdout.decode())
        return stdout.decode()

def create_directory(directory):
    if not os.path.exists(directory):
        os.mkdir(directory)
        print(f"Directory {directory} created.")
    else:
        print(f"Directory {directory} already exists.")

# Define the source and destination paths
source_path1 = '~/mal-parse/investigate/threat_analysis/new_threats.json'
source_path2 = '~/mal-parse/investigate/report.json'
destination_path1 = '~/mal-parse/admin/static/new_threats.json'
destination_path2 = '~/mal-parse/admin/static/report.json'

# Create the destination directory if it doesn't exist
create_directory(os.path.expanduser('~/admin/static'))

# Copy the files
execute_command(f'cp {os.path.expanduser(source_path1)} {os.path.expanduser(destination_path1)}')
execute_command(f'cp {os.path.expanduser(source_path2)} {os.path.expanduser(destination_path2)}')

# Change to the /admin directory
os.chdir(os.path.expanduser('~/mal-parse/admin/static'))

# Run the commands
print(f"{white}Taking care of report formatting...{white}")
execute_command('python3 replace.py')
time.sleep(5)

print(f"{white}Taking care of the threats formatting...{white}")
execute_command('./format.sh')
time.sleep(5)

print(f"{white}Creating the daily threats file...{white}")
execute_command('python3 translate.py')
time.sleep(5)

os.chdir(os.path.expanduser('~/mal-parse/admin/'))

print(f"{white}Making migrations...{white}")
execute_command('python3 manage.py makemigrations')
time.sleep(5)

execute_command('python3 manage.py migrate --run-syncdb')
time.sleep(5)

print(f"{white}Please create your malparse superuser...{white}")
superuser_check_output = execute_admin_command('python3 manage.py checksuperuser')
if 'No superuser.' in superuser_check_output:
    execute_command('python3 manage.py createsuperuser')
time.sleep(5)

execute_command(f'mv static/formatted_report.json .' ) 

print(f"{green}Loading data...{white}")
execute_command('python3 manage.py load_data')
time.sleep(5)

execute_command('clear')
time.sleep(5)

print(f"{green}Thank you for using Mal-Parse!{green}")
print(f"{green}Starting Dashboard...{green}")
execute_command('python3 manage.py runserver')

# -----------------------------------------------------> END PYTHON3 COMMANDS <-----------------------------------------------------


#print(f"{green}Restarting At 8AM 24/UTC.{green}")"